<?php

namespace App\Enums;

enum UserGenderEnum: string
{
    case male = 'Male';
    case female = 'Female';
}
