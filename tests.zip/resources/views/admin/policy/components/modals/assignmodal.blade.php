<!-- Add Policy Modal -->
<div id="assign_policy" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Assign Policy</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="assing_policy_data">

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Add Policy Modal -->

@push('modal-script')
@endpush
