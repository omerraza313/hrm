<!-- Delete Employee Modal -->
<div class="modal custom-modal fade" id="deactive_view_modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-header">
                    <h3>Deactive Employee View</h3>
                </div>
                <div class="modal-btn">
                    <div id="view_deactive_data">

                    </div>
                    <div class="col-12">
                        <a href="javascript:void(0);" data-bs-dismiss="modal"
                            class="btn btn-primary cancel-btn">Close</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- /Delete Employee Modal -->
